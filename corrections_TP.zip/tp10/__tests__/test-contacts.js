const ContactService = require("../ContactService");

describe("Contacts object", () => {
  let myContacts;

  describe("toString", () => {
    beforeEach(() => {
      myContacts = new ContactService();
    });

    it("should return lastName in upper case", () => {
      const contact = myContacts.contacts[0];
      const string = contact.toString();

      expect(string).toMatch(/^[A-Z]* [A-Za-z]*/);
    });
  });
});
