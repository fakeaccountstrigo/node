#!/usr/bin/env node

const MongoContactService = require('./MongoContactService');
const cli = require('./Cli');

/* Execution */
const a = 3;
const b = 5;
const test = {
  sum () {
    return a + b;
  }
}
console.log(test.sum())

// const myContacts = new MongoContactService();
//cli.init(myContacts);
