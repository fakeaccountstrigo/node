const fs = require('fs');

const path = 'contacts.json';
const backupPath = path + ".back";

exports.callback = (contacts, callback) => {
  fs.readFile(path, (err, data) => {
    if (err) {
      console.error(err);
    } else {
      fs.writeFile(backupPath, data, (err) => {
        if (err) {
          console.error(err);
        } else {
          fs.writeFile(path, JSON.stringify(contacts, undefined, 2), (err) => {
            if (err) {
              console.error(err);

              fs.rename(backupPath, path, (err) => {
                if (err) {
                  console.error(err);
                }

                if (callback) {
                  callback();
                }
              });
            } else {
              fs.unlink(backupPath, (err) => {
                if (err) {
                  console.error(err);
                }

                if (callback) {
                  callback();
                }
              });
            }
          });
        }
      });
    }
  });
};

exports.promise = (contacts, callback) => fs.promises.readFile(path)
  .then((data) => {
    console.log('Read', data.toString());
    return fs.promises.writeFile(backupPath, data);
  })
  .then(() => {
    console.log('Write');
    return fs.promises.writeFile(path, JSON.stringify(contacts, undefined, 2))
      .then(
        () => fs.promises.unlink(backupPath))
      .catch(
        (err) => {
          console.log('Error writing file', err);
          return fs.promises.rename(backupPath, path);
        }
      )
  })
  .then(() => {
    if (callback) {
      callback();
    }
  })
  .catch((err) => {
    console.error('Error', err);
  });

async function doAsyncAwait (contacts) {
  const data = await fs.promises.readFile(path);
  await fs.promises.writeFile(backupPath, data);
  try {
    await fs.promises.writeFile(path, JSON.stringify(contacts, undefined, 2));
  } catch (err) {
    await fs.promises.rename(backupPath, path);
  } finally {
    await fs.promises.unlink(backupPath);
  }

  return data;
}

exports.asyncAwait = async (contacts, callback) => {
  try {
    await doAsyncAwait(contacts)
    callback()
  } catch (e) {
    callback()
  }
};
